#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Functions.h"
#include "cctk_Parameters.h"

subroutine qlm_calc_dh_flux (CCTK_ARGUMENTS, hn)
  use cctk
  use adm_metric
  use qlm_derivs
  use qlm_variables
  implicit none
  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_FUNCTIONS
  DECLARE_CCTK_PARAMETERS
  integer, intent(in) :: hn
  integer :: i,j,l,a,b,ii,jj,kk,uu,vv,ntheta_inner,nphi_inner
  real(kind=8) :: theta,sum1,weight,dtq,measure
  real(kind=8) :: ll(0:3),nn(0:3),ss(0:3),tt(0:3),rhat(0:3),m1(0:3),m2(0:3)
  real(kind=8) :: z1,z2,zeta2,sigma2,worldtube_measure,full_flux_density,boost
  real(kind=8) :: ch,ea,lscale,nscale,b11,b12,b21,b22,b12s,theta_l,theta_n
  real(kind=8) :: sig11,sig12,sig21,sig22,sigma2_direct,zeta2_direct
  real(kind=8) :: ak_full_flux_density
  real(kind=8) :: phi,h,theta_a,theta_b,theta_c,theta_d,theta_ah
  real(kind=8) :: xunit(3),xcoord,ycoord,zcoord,xud(2,3),xtan(2,3),xsec(2,2,3),xudd(2,3,3),dh(2),ddh(2,2)
  real(kind=8) :: sd(3),dsd(3,3),ginv(3,3),dmetric(3,3,3),kmat(3,3)
  real(kind=8) :: gamma3(3,3,3),scov(3),crossv(3),q2(2,2),q2i(2,2),kab(2,2),btf(2,2)
  real(kind=8) :: ksurf(2,2),theta_3p,sigma2_3p,detq2,nsq,ktrace3
  real(kind=8) :: gg(3,3)
  real(kind=8) :: alfa,beta(3),g4(0:3,0:3)
  real(kind=8) :: rr(3),rr_p(3),rr_p_p(3),ttilde(0:3),tnorm
  real(kind=8) :: t0,t1,t2,At,Bs,ratio,geo_boost,geo_ch,geo_ea,geo_lscale
  real(kind=8) :: geo_rhat(0:3),geo_z1,geo_z2,geo_zeta2
  real(kind=8) :: sb11,sb12,sb21,sb22,st12,sg11,sg12,sg22,sigma_geo2
  logical :: ce0,ce1,ce2
  real(kind=8) :: dln(3),detg,invdet,temp
  complex(kind=8) :: sig
  real(kind=8), parameter :: pi=3.1415926535897932384626433832795d0
  real(kind=8), parameter :: rt2=1.4142135623730950488d0

  qlm_dh_sigma_integral(hn)=0.d0
  qlm_dh_zeta_integral(hn)=0.d0
  qlm_dh_flux_integral(hn)=0.d0
  qlm_dh_worldtube_measure_integral(hn)=0.d0
  qlm_dh_full_flux_surface_integral(hn)=0.d0
  qlm_dh_null_normalization(hn)=1.d0/rt2
  ! The tangent zeta components are reconstructed directly from the QLM
  ! tetrad derivative convention below.  The DH world-tube lapse/evolution
  ! factor is still not reconstructed here, so this remains a surface
  ! diagnostic rather than the complete N_R-weighted balance integral.
  qlm_dh_evolution_status(hn)=1.d0
  ntheta_inner=qlm_ntheta(hn)-2*qlm_nghoststheta(hn)
  nphi_inner=qlm_nphi(hn)-2*qlm_nghostsphi(hn)
  t0=qlm_time(hn); t1=qlm_time_p(hn); t2=qlm_time_p_p(hn)
  ce0=qlm_have_valid_data(hn)==0
  ce1=qlm_have_valid_data_p(hn)==0
  ce2=qlm_have_valid_data_p_p(hn)==0

  do j=1+qlm_nghostsphi(hn),qlm_nphi(hn)-qlm_nghostsphi(hn)
     do i=1+qlm_nghoststheta(hn),qlm_ntheta(hn)-qlm_nghoststheta(hn)
        theta=qlm_origin_theta(hn)+(i-1)*qlm_delta_theta(hn)
        phi=qlm_origin_phi(hn)+(j-1)*qlm_delta_phi(hn)
        sum1=0.d0
        do l=0,(ntheta_inner-1)/2
           sum1=sum1+sin((2*l+1)*theta)/(2*l+1)
        end do
        weight=8.d0*pi*sum1/(nphi_inner*ntheta_inner)
        ll=(/qlm_l0(i,j,hn),qlm_l1(i,j,hn),qlm_l2(i,j,hn),qlm_l3(i,j,hn)/)
        nn=(/qlm_n0(i,j,hn),qlm_n1(i,j,hn),qlm_n2(i,j,hn),qlm_n3(i,j,hn)/)
         ss=(ll-nn)/rt2
         tt=(ll+nn)/rt2
        m1=rt2*(/real(qlm_m0(i,j,hn)),real(qlm_m1(i,j,hn)),real(qlm_m2(i,j,hn)),real(qlm_m3(i,j,hn))/)
        m2=rt2*(/aimag(qlm_m0(i,j,hn)),aimag(qlm_m1(i,j,hn)),aimag(qlm_m2(i,j,hn)),aimag(qlm_m3(i,j,hn))/)
        ! QLM constructs l=(t+s)/sqrt(2), n=(t-s)/sqrt(2), hence
        ! s=(l-n)/sqrt(2).  Its tetrad source stores
        ! With m=(m1+i*m2)/sqrt(2), the
        ! projected DH connection one-form is
        ! zeta_A = e_A^b s^a nabla_a l_b, A=1,2.
        ! qlm_tetrad_derivs stores nabla_ll(a,b)=D_b l_a, so the
        ! l-index and derivative-index must be transposed here:
        ! nabla_ll(b,a)=D_a l_b.
        ! The tangent basis is orthonormal, so |zeta|^2=z1^2+z2^2.
        z1=0.d0; z2=0.d0
        do a=0,3
           do b=0,3
              z1=z1+ss(a)*m1(b)*qlm_tetrad_derivs(i,j)%nabla_ll(b,a)
              z2=z2+ss(a)*m2(b)*qlm_tetrad_derivs(i,j)%nabla_ll(b,a)
           end do
        end do
        zeta2=z1*z1+z2*z2
        gg(1,1)=qlm_gxx(i,j); gg(1,2)=qlm_gxy(i,j); gg(1,3)=qlm_gxz(i,j)
        gg(2,1)=gg(1,2); gg(2,2)=qlm_gyy(i,j); gg(2,3)=qlm_gyz(i,j)
        gg(3,1)=gg(1,3); gg(3,2)=gg(2,3); gg(3,3)=qlm_gzz(i,j)
        alfa=qlm_alpha(i,j)
        beta=(/qlm_betax(i,j),qlm_betay(i,j),qlm_betaz(i,j)/)
        call calc_4metric(gg,alfa,beta,g4)
        rr=(/qlm_x(i,j,hn),qlm_y(i,j,hn),qlm_z(i,j,hn)/)
        rr_p=(/qlm_x_p(i,j,hn),qlm_y_p(i,j,hn),qlm_z_p(i,j,hn)/)
        rr_p_p=(/qlm_x_p_p(i,j,hn),qlm_y_p_p(i,j,hn),qlm_z_p_p(i,j,hn)/)
        ttilde(0)=1.d0
        ttilde(1:3)=timederiv(rr,rr_p,rr_p_p,t0,t1,t2,ce0,ce1,ce2)
        At=-sum(tt*matmul(g4,ttilde)); Bs=sum(ss*matmul(g4,ttilde))
        ratio=At/(Bs+1.d-300)
        if (abs(ratio)<1.d0) then
           geo_boost=ratio/sqrt(max(1.d0-ratio*ratio,1.d-300))
        else
           geo_boost=0.d0
        end if
        geo_ch=sqrt(1.d0+geo_boost*geo_boost); geo_ea=geo_ch+geo_boost
        geo_lscale=rt2*geo_ea; geo_rhat=geo_ch*ss+geo_boost*tt
        geo_z1=0.d0; geo_z2=0.d0
        do a=0,3
           do b=0,3
              geo_z1=geo_z1+geo_rhat(a)*m1(b)*qlm_tetrad_derivs(i,j)%nabla_ll(b,a)
              geo_z2=geo_z2+geo_rhat(a)*m2(b)*qlm_tetrad_derivs(i,j)%nabla_ll(b,a)
           end do
        end do
        geo_zeta2=(geo_lscale*geo_z1)**2+(geo_lscale*geo_z2)**2
        ! Producer-native geometric-boost shear in the same orthonormal
        ! transverse dyad used for the AK projection.  This is emitted as
        ! components plus its direct tensor norm; it is not inferred from
        ! the old determinant-ratio boost path.
        sb11=0.d0; sb12=0.d0; sb21=0.d0; sb22=0.d0
        do a=0,3
           do b=0,3
              sb11=sb11+m1(a)*m1(b)*qlm_tetrad_derivs(i,j)%nabla_ll(a,b)
              sb12=sb12+m1(a)*m2(b)*qlm_tetrad_derivs(i,j)%nabla_ll(a,b)
              sb21=sb21+m2(a)*m1(b)*qlm_tetrad_derivs(i,j)%nabla_ll(a,b)
              sb22=sb22+m2(a)*m2(b)*qlm_tetrad_derivs(i,j)%nabla_ll(a,b)
           end do
        end do
        sb11=geo_lscale*sb11; sb12=geo_lscale*sb12
        sb21=geo_lscale*sb21; sb22=geo_lscale*sb22
        st12=0.5d0*(sb12+sb21)
        sg11=sb11-0.5d0*(sb11+sb22)
        sg12=st12
        sg22=sb22-0.5d0*(sb11+sb22)
        sigma_geo2=sg11*sg11+2.d0*sg12*sg12+sg22*sg22
        sig=qlm_npsigma(i,j,hn)
        ! With m=(m1+i*m2)/sqrt(2), sigma_ab sigma^ab=2|sigma_NP|^2.
        sigma2=2.d0*real(sig*conjg(sig))
        dtq=qlm_qtt(i,j,hn)*qlm_qpp(i,j,hn)-qlm_qtp(i,j,hn)**2
        measure=sqrt(max(dtq,0.d0))*weight

        ! Reconstruct the AHFinderDirect 3+1 MOTS expansion on this
        ! identical spherical surface.  This is the source formula from
        ! AHFinderDirect/src/gr/horizon.maple, not the full 4D connection
        ! contraction used by dh_ak_theta_l.
        h=qlm_shape(i,j,hn)
        xunit=(/sin(theta)*cos(phi),sin(theta)*sin(phi),cos(theta)/)
        xcoord=h*xunit(1); ycoord=h*xunit(2); zcoord=h*xunit(3)
        ! xud is the AHFinder level-set gradient du/dx used below for the
        ! normal.  The induced surface metric requires the opposite object:
        ! the Cartesian embedding tangents dX/du.
        dh=deriv(qlm_shape(:,:,hn),i,j,(/qlm_delta_theta(hn),qlm_delta_phi(hn)/))
        ddh=deriv2(qlm_shape(:,:,hn),i,j,(/qlm_delta_theta(hn),qlm_delta_phi(hn)/))
        xtan(1,:)=dh(1)*xunit+h*(/cos(theta)*cos(phi),cos(theta)*sin(phi),-sin(theta)/)
        xtan(2,:)=dh(2)*xunit+h*(/-sin(theta)*sin(phi),sin(theta)*cos(phi),0.d0/)
        xsec(1,1,:)=ddh(1,1)*xunit+2.d0*dh(1)*(/cos(theta)*cos(phi),cos(theta)*sin(phi),-sin(theta)/) &
             +h*(/-sin(theta)*cos(phi),-sin(theta)*sin(phi),-cos(theta)/)
        xsec(1,2,:)=ddh(1,2)*xunit+dh(1)*(/-sin(theta)*sin(phi),sin(theta)*cos(phi),0.d0/) &
             +dh(2)*(/cos(theta)*cos(phi),cos(theta)*sin(phi),-sin(theta)/) &
             +h*(/-cos(theta)*sin(phi),cos(theta)*cos(phi),0.d0/)
        xsec(2,1,:)=xsec(1,2,:)
        xsec(2,2,:)=ddh(2,2)*xunit+2.d0*dh(2)*(/-sin(theta)*sin(phi),sin(theta)*cos(phi),0.d0/) &
             +h*(/-sin(theta)*cos(phi),-sin(theta)*sin(phi),0.d0/)
        ! Exact AHFinderDirect patch coefficients from coords.cc.
        xud(1,:)=(/zcoord/(xcoord*xcoord+zcoord*zcoord),0.d0, &
             -xcoord/(xcoord*xcoord+zcoord*zcoord)/)
        xud(2,:)=(/-ycoord/(xcoord*xcoord+ycoord*ycoord), &
             xcoord/(xcoord*xcoord+ycoord*ycoord),0.d0/)
        xudd=0.d0
        xudd(1,1,1)=-2.d0*xcoord*zcoord/(xcoord*xcoord+zcoord*zcoord)**2
        xudd(1,1,3)=(xcoord*xcoord-zcoord*zcoord)/(xcoord*xcoord+zcoord*zcoord)**2
        xudd(1,3,1)=xudd(1,1,3)
        xudd(1,3,3)=2.d0*xcoord*zcoord/(xcoord*xcoord+zcoord*zcoord)**2
        xudd(2,1,1)=2.d0*xcoord*ycoord/(xcoord*xcoord+ycoord*ycoord)**2
        xudd(2,1,2)=(ycoord*ycoord-xcoord*xcoord)/(xcoord*xcoord+ycoord*ycoord)**2
        xudd(2,2,1)=xudd(2,1,2)
        xudd(2,2,2)=-2.d0*xcoord*ycoord/(xcoord*xcoord+ycoord*ycoord)**2
        do ii=1,3
           sd(ii)=xunit(ii)
           do uu=1,2
              sd(ii)=sd(ii)-xud(uu,ii)*dh(uu)
           end do
           do jj=1,3
              if (ii == jj) then
                 temp=sum(xunit*xunit)-xunit(ii)*xunit(ii)
              else
                 temp=-xunit(ii)*xunit(jj)
              end if
              dsd(ii,jj)=temp
              do uu=1,2
                 dsd(ii,jj)=dsd(ii,jj)-xudd(uu,ii,jj)*dh(uu)
                 do vv=1,2
                    dsd(ii,jj)=dsd(ii,jj)-xud(uu,ii)*xud(vv,jj)*ddh(uu,vv)
                 end do
              end do
           end do
        end do
        gg(1,1)=qlm_gxx(i,j); gg(1,2)=qlm_gxy(i,j); gg(1,3)=qlm_gxz(i,j)
        gg(2,1)=gg(1,2); gg(2,2)=qlm_gyy(i,j); gg(2,3)=qlm_gyz(i,j)
        gg(3,1)=gg(1,3); gg(3,2)=gg(2,3); gg(3,3)=qlm_gzz(i,j)
        detg=gg(1,1)*(gg(2,2)*gg(3,3)-gg(2,3)*gg(2,3)) &
             -gg(1,2)*(gg(1,2)*gg(3,3)-gg(2,3)*gg(1,3)) &
             +gg(1,3)*(gg(1,2)*gg(2,3)-gg(2,2)*gg(1,3))
        invdet=1.d0/detg
        ginv(1,1)=(gg(2,2)*gg(3,3)-gg(2,3)*gg(2,3))*invdet
        ginv(1,2)=(gg(1,3)*gg(2,3)-gg(1,2)*gg(3,3))*invdet
        ginv(1,3)=(gg(1,2)*gg(2,3)-gg(1,3)*gg(2,2))*invdet
        ginv(2,1)=ginv(1,2)
        ginv(2,2)=(gg(1,1)*gg(3,3)-gg(1,3)*gg(1,3))*invdet
        ginv(2,3)=(gg(1,2)*gg(1,3)-gg(1,1)*gg(2,3))*invdet
        ginv(3,1)=ginv(1,3); ginv(3,2)=ginv(2,3)
        ginv(3,3)=(gg(1,1)*gg(2,2)-gg(1,2)*gg(1,2))*invdet
        dmetric=0.d0
        dmetric(1,1,1)=qlm_dgxxx(i,j); dmetric(1,1,2)=qlm_dgxyx(i,j); dmetric(1,1,3)=qlm_dgxzx(i,j)
        dmetric(1,2,1)=dmetric(1,1,2); dmetric(1,2,2)=qlm_dgyyx(i,j); dmetric(1,2,3)=qlm_dgyzx(i,j)
        dmetric(1,3,1)=dmetric(1,1,3); dmetric(1,3,2)=dmetric(1,2,3); dmetric(1,3,3)=qlm_dgzzx(i,j)
        dmetric(2,1,1)=qlm_dgxxy(i,j); dmetric(2,1,2)=qlm_dgxyy(i,j); dmetric(2,1,3)=qlm_dgxzy(i,j)
        dmetric(2,2,1)=dmetric(2,1,2); dmetric(2,2,2)=qlm_dgyyy(i,j); dmetric(2,2,3)=qlm_dgyzy(i,j)
        dmetric(2,3,1)=dmetric(2,1,3); dmetric(2,3,2)=dmetric(2,2,3); dmetric(2,3,3)=qlm_dgzzy(i,j)
        dmetric(3,1,1)=qlm_dgxxz(i,j); dmetric(3,1,2)=qlm_dgxyz(i,j); dmetric(3,1,3)=qlm_dgxzz(i,j)
        dmetric(3,2,1)=dmetric(3,1,2); dmetric(3,2,2)=qlm_dgyyz(i,j); dmetric(3,2,3)=qlm_dgyzz(i,j)
        dmetric(3,3,1)=dmetric(3,1,3); dmetric(3,3,2)=dmetric(3,2,3); dmetric(3,3,3)=qlm_dgzzz(i,j)
        kmat(1,1)=qlm_kxx(i,j); kmat(1,2)=qlm_kxy(i,j); kmat(1,3)=qlm_kxz(i,j)
        kmat(2,1)=kmat(1,2); kmat(2,2)=qlm_kyy(i,j); kmat(2,3)=qlm_kyz(i,j)
        kmat(3,1)=kmat(1,3); kmat(3,2)=kmat(2,3); kmat(3,3)=qlm_kzz(i,j)
        do kk=1,3
           dln(kk)=0.d0
           do ii=1,3
              do jj=1,3
                 dln(kk)=dln(kk)+0.5d0*ginv(ii,jj)*dmetric(kk,ii,jj)
              end do
           end do
        end do
        theta_a=0.d0; theta_b=0.d0; theta_c=0.d0; theta_d=0.d0
        do ii=1,3
           do jj=1,3
              theta_d=theta_d+ginv(ii,jj)*sd(ii)*sd(jj)
              theta_c=theta_c+kmat(ii,jj)*sd(ii)*sd(jj)
              theta_b=theta_b+ginv(ii,jj)*dsd(ii,jj)+ginv(ii,jj)*dln(ii)*sd(jj)
              do kk=1,3
                 do uu=1,3
                    theta_a=theta_a-ginv(ii,kk)*sd(kk)*ginv(jj,uu)*sd(uu)*dsd(ii,jj)
                    theta_a=theta_a-0.5d0*ginv(ii,jj)*sd(jj)*dmetric(ii,kk,uu)*sd(kk)*sd(uu)
                 end do
              end do
              theta_b=theta_b+dmetric(ii,ii,jj)*sd(jj)
           end do
        end do
        ! Independent AHFinder-compatible 3+1 surface expansion/shear audit.
        ! The surface normal is the metric-normalized covector sd; the
        ! second fundamental form is evaluated from the same Cartesian
        ! embedding derivatives and 3-connection used by the AH equation.
        crossv(1)=xtan(1,2)*xtan(2,3)-xtan(1,3)*xtan(2,2)
        crossv(2)=xtan(1,3)*xtan(2,1)-xtan(1,1)*xtan(2,3)
        crossv(3)=xtan(1,1)*xtan(2,2)-xtan(1,2)*xtan(2,1)
        do ii=1,3
           scov(ii)=0.d0
           do jj=1,3
              scov(ii)=scov(ii)+gg(ii,jj)*crossv(jj)
           end do
        end do
        nsq=sqrt(max(sum(scov*MATMUL(ginv,scov)),1.d-300))
        scov=scov/nsq
        do ii=1,3
           do jj=1,3
              do kk=1,3
                 gamma3(ii,jj,kk)=0.d0
                 do uu=1,3
                    gamma3(ii,jj,kk)=gamma3(ii,jj,kk)+0.5d0*ginv(ii,uu)* &
                         (dmetric(jj,uu,kk)+dmetric(kk,uu,jj)-dmetric(uu,jj,kk))
                 end do
              end do
           end do
        end do
        do uu=1,2
           do vv=1,2
              q2(uu,vv)=0.d0
              ksurf(uu,vv)=0.d0
              do ii=1,3
                 do jj=1,3
                    q2(uu,vv)=q2(uu,vv)+gg(ii,jj)*xtan(uu,ii)*xtan(vv,jj)
                    ksurf(uu,vv)=ksurf(uu,vv)+kmat(ii,jj)*xtan(uu,ii)*xtan(vv,jj)
                 end do
              end do
              kab(uu,vv)=0.d0
              do kk=1,3
                 kab(uu,vv)=kab(uu,vv)+scov(kk)*xsec(uu,vv,kk)
                 do ii=1,3
                    do jj=1,3
                       kab(uu,vv)=kab(uu,vv)+scov(kk)*gamma3(kk,ii,jj)*xtan(uu,ii)*xtan(vv,jj)
                    end do
                 end do
              end do
           end do
        end do
        detq2=q2(1,1)*q2(2,2)-q2(1,2)*q2(2,1)
        q2i(1,1)=q2(2,2)/detq2; q2i(1,2)=-q2(1,2)/detq2
        q2i(2,1)=q2i(1,2); q2i(2,2)=q2(1,1)/detq2
        ktrace3=0.d0
        do ii=1,3
           do jj=1,3
              ktrace3=ktrace3+ginv(ii,jj)*kmat(ii,jj)
           end do
        end do
        ! AHFinderDirect's Theta_X is the outward positive mean-curvature
        ! convention.  With the outward cross-product normal above, the
        ! embedding second form has the same sign.  Its Theta_Y term is
        ! q^AB K_AB - K, matching AHFinderDirect's Theta_C/Theta_D - K.
        theta_3p=-ktrace3
        do uu=1,2
           do vv=1,2
              theta_3p=theta_3p+q2i(uu,vv)*kab(uu,vv)+q2i(uu,vv)*ksurf(uu,vv)
           end do
        end do
        do uu=1,2
           do vv=1,2
              btf(uu,vv)=+kab(uu,vv)+ksurf(uu,vv)-0.5d0*q2(uu,vv)*theta_3p
           end do
        end do
        sigma2_3p=0.d0
        do uu=1,2
           do vv=1,2
              do ii=1,2
                 do jj=1,2
                    sigma2_3p=sigma2_3p+q2i(uu,ii)*q2i(vv,jj)*btf(uu,vv)*btf(ii,jj)
                 end do
              end do
           end do
        end do
        ! Expose the independent 3+1 candidate through the AHFinder
        ! diagnostic slot.  theta_3p already contains the projected
        ! tangential K term; subtracting the full 3D K trace here would be a
        ! second, unrelated subtraction and would corrupt the expansion.
        theta_ah=theta_3p
        ! qlm_3det is the determinant of the induced 3-metric Q on the
        ! horizon world tube for the coordinate-time tangent T=(1,dx/dt).
        ! This is the coordinate-time 3-volume density.  It is emitted as
        ! an explicit diagnostic; the N_R/boost factor is not silently
        ! inferred here.
        worldtube_measure=sqrt(max(qlm_3det(i,j,hn),0.d0))*weight
        full_flux_density=(sigma2+2.d0*zeta2)*worldtube_measure
         if (dtq > 0.d0 .and. qlm_3det(i,j,hn) > 0.d0) then
           ! From the ETK world-tube transformation:
           ! sqrt(det Q_coord)/sqrt(det q) = d sigma/dt = sinh(alpha).
           boost=sqrt(qlm_3det(i,j,hn)/dtq)
        else
            boost=0.d0
         end if
         ch=sqrt(1.d0+boost*boost)
         ea=ch+boost
         lscale=rt2*ea
         nscale=rt2*(ch-boost)
         rhat=ch*ss+boost*tt

         ! Direct AK horizon-adapted contraction.  The derivative of the
         ! boost factor drops out after tangent projection because m_A.l=0.
         b11=0.d0; b12=0.d0; b21=0.d0; b22=0.d0
         z1=0.d0; z2=0.d0
         theta_n=0.d0
         do a=0,3
            do b=0,3
               ! qlm_tetrad_derivs(a,b)=D_b l_a.  Form B_AB=e_A^a e_B^b D_b l_a
               ! with the original index order, then take its symmetric part.
               b11=b11+m1(a)*m1(b)*qlm_tetrad_derivs(i,j)%nabla_ll(a,b)
               b12=b12+m1(a)*m2(b)*qlm_tetrad_derivs(i,j)%nabla_ll(a,b)
               b21=b21+m2(a)*m1(b)*qlm_tetrad_derivs(i,j)%nabla_ll(a,b)
               b22=b22+m2(a)*m2(b)*qlm_tetrad_derivs(i,j)%nabla_ll(a,b)
               z1=z1+rhat(a)*m1(b)*qlm_tetrad_derivs(i,j)%nabla_ll(b,a)
               z2=z2+rhat(a)*m2(b)*qlm_tetrad_derivs(i,j)%nabla_ll(b,a)
               theta_n=theta_n+m1(a)*m1(b)*qlm_tetrad_derivs(i,j)%nabla_nn(b,a)
               theta_n=theta_n+m2(a)*m2(b)*qlm_tetrad_derivs(i,j)%nabla_nn(b,a)
            end do
         end do
         b11=lscale*b11; b12=lscale*b12; b21=lscale*b21; b22=lscale*b22
         theta_l=b11+b22
         sig11=b11-0.5d0*theta_l
         b12s=0.5d0*(b12+b21)
         sig12=b12s
         sig21=b12s
         sig22=b22-0.5d0*theta_l
         sigma2_direct=sig11*sig11+sig12*sig12+sig21*sig21+sig22*sig22
         zeta2_direct=(lscale*z1)**2+(lscale*z2)**2
         theta_n=nscale*theta_n
         ak_full_flux_density=(sigma2_direct+2.d0*zeta2_direct)*worldtube_measure
        qlm_dh_sigma2(i,j,hn)=sigma2
        qlm_dh_zeta2(i,j,hn)=zeta2
        qlm_dh_flux_density(i,j,hn)=sigma2
        qlm_dh_measure(i,j,hn)=measure
        qlm_dh_worldtube_measure(i,j,hn)=worldtube_measure
         qlm_dh_full_flux_density(i,j,hn)=full_flux_density
         qlm_dh_ak_sigma_tensor2(i,j,hn)=sigma2_direct
         qlm_dh_ak_zeta_direct2(i,j,hn)=zeta2_direct
         qlm_dh_ak_b11(i,j,hn)=b11
         qlm_dh_ak_b12(i,j,hn)=b12
         qlm_dh_ak_b21(i,j,hn)=b21
         qlm_dh_ak_b22(i,j,hn)=b22
         qlm_dh_ak_theta_l(i,j,hn)=theta_l
         qlm_dh_ak_theta_n(i,j,hn)=theta_n
         qlm_dh_ahfinder_theta(i,j,hn)=theta_ah
         qlm_dh_ak_full_flux_density(i,j,hn)=ak_full_flux_density
         qlm_dh_zeta_raw_1(i,j,hn)=geo_z1
         qlm_dh_zeta_raw_2(i,j,hn)=geo_z2
         qlm_dh_zeta_geo_1(i,j,hn)=geo_lscale*geo_z1
         qlm_dh_zeta_geo_2(i,j,hn)=geo_lscale*geo_z2
         qlm_dh_zeta_geo2(i,j,hn)=geo_zeta2
         qlm_dh_sigma_geo_11(i,j,hn)=sg11
         qlm_dh_sigma_geo_12(i,j,hn)=sg12
         qlm_dh_sigma_geo_22(i,j,hn)=sg22
         qlm_dh_sigma_geo2(i,j,hn)=sigma_geo2
         qlm_dh_T_t(i,j,hn)=At
         qlm_dh_T_s(i,j,hn)=Bs
         qlm_dh_sinh_alpha_geo(i,j,hn)=geo_boost
         qlm_dh_cosh_alpha_geo(i,j,hn)=geo_ch
         qlm_dh_lscale_geo(i,j,hn)=geo_lscale
         qlm_dh_3p_sigma2(i,j,hn)=sigma2_3p
         qlm_dh_3p_flux_density(i,j,hn)=(sigma2_3p+2.d0*zeta2_direct)*worldtube_measure
        qlm_dh_sinh_alpha(i,j,hn)=boost
        qlm_dh_N_R(i,j,hn)=0.d0
        qlm_dh_ak_flux_density(i,j,hn)=0.d0
        qlm_dh_sigma_integral(hn)=qlm_dh_sigma_integral(hn)+sigma2*measure
        qlm_dh_zeta_integral(hn)=qlm_dh_zeta_integral(hn)+zeta2*measure
        qlm_dh_flux_integral(hn)=qlm_dh_flux_integral(hn)+sigma2*measure
        qlm_dh_worldtube_measure_integral(hn)=qlm_dh_worldtube_measure_integral(hn)+worldtube_measure
        qlm_dh_full_flux_surface_integral(hn)=qlm_dh_full_flux_surface_integral(hn)+full_flux_density
     end do
  end do
end subroutine qlm_calc_dh_flux
