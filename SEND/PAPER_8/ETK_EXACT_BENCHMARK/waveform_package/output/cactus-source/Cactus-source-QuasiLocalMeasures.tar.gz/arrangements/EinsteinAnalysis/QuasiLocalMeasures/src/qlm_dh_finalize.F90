#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Functions.h"
#include "cctk_Parameters.h"

subroutine qlm_dh_finalize (CCTK_ARGUMENTS, hn)
  use qlm_variables
  implicit none
  DECLARE_CCTK_FUNCTIONS
  DECLARE_CCTK_PARAMETERS
  DECLARE_CCTK_ARGUMENTS
  integer, intent(in) :: hn
  integer :: i,j,nvalid
  real(kind=8) :: dt, drdt, boost, ak_integral
  real(kind=8) :: sum_tn2,sum_tr2,sum_td2,sum_sp2,sum_zp2
  real(kind=8) :: asum_tn2,asum_tr2,asum_td2,asum_sp2,asum_zp2,asum
  real(kind=8) :: max_td,detmin,den,refsig,refzet,ea,ch
  complex(kind=8) :: zeta_ref

  qlm_dh_dR_dt(hn) = 0.d0
  qlm_dh_nr_full_flux_rate(hn) = 0.d0
  qlm_dh_ak_flux_surface_integral(hn) = 0.d0
  qlm_dh_surface_time(hn) = qlm_time(hn)
  qlm_dh_surface_iteration(hn) = real(qlm_iteration(hn),kind=8)
  qlm_dh_audit_det3_min(hn) = 0.d0
  qlm_dh_audit_theta_native_rms(hn) = -1.d0
  qlm_dh_audit_theta_recon_rms(hn) = -1.d0
  qlm_dh_audit_theta_diff_rms(hn) = -1.d0
  qlm_dh_audit_theta_diff_max(hn) = -1.d0
  qlm_dh_audit_sigma_parity_rel_rms(hn) = -1.d0
  qlm_dh_audit_zeta_parity_rel_rms(hn) = -1.d0
  qlm_dh_audit_theta_native_area_rms(hn) = -1.d0
  qlm_dh_audit_theta_recon_area_rms(hn) = -1.d0
  qlm_dh_audit_theta_diff_area_rms(hn) = -1.d0
  qlm_dh_audit_sigma_parity_rel_area_rms(hn) = -1.d0
  qlm_dh_audit_zeta_parity_rel_area_rms(hn) = -1.d0
  qlm_dh_audit_valid_surface_fraction(hn) = 0.d0
  ! AHFinder does not currently export a native pointwise normal/projector.
  qlm_dh_audit_normal_diff_rms(hn) = -1.d0
  qlm_dh_audit_projector_diff_rms(hn) = -1.d0

  sum_tn2=0.d0; sum_tr2=0.d0; sum_td2=0.d0
  sum_sp2=0.d0; sum_zp2=0.d0; max_td=0.d0; detmin=huge(1.d0); nvalid=0
  asum_tn2=0.d0; asum_tr2=0.d0; asum_td2=0.d0; asum_sp2=0.d0; asum_zp2=0.d0; asum=0.d0
  do j=1+qlm_nghostsphi(hn),qlm_nphi(hn)-qlm_nghostsphi(hn)
     do i=1+qlm_nghoststheta(hn),qlm_ntheta(hn)-qlm_nghoststheta(hn)
        sum_tn2=sum_tn2+qlm_dh_ahfinder_theta(i,j,hn)**2
        sum_tr2=sum_tr2+qlm_dh_ak_theta_l(i,j,hn)**2
        den=qlm_dh_ahfinder_theta(i,j,hn)-qlm_dh_ak_theta_l(i,j,hn)
        sum_td2=sum_td2+den**2
        max_td=max(max_td,abs(den))
        detmin=min(detmin,qlm_3det(i,j,hn))
        asum=asum+qlm_dh_measure(i,j,hn)
        asum_tn2=asum_tn2+qlm_dh_measure(i,j,hn)*qlm_dh_ahfinder_theta(i,j,hn)**2
        asum_tr2=asum_tr2+qlm_dh_measure(i,j,hn)*qlm_dh_ak_theta_l(i,j,hn)**2
        asum_td2=asum_td2+qlm_dh_measure(i,j,hn)*(qlm_dh_ahfinder_theta(i,j,hn)-qlm_dh_ak_theta_l(i,j,hn))**2
        boost=qlm_dh_sinh_alpha(i,j,hn)
        ch=sqrt(1.d0+boost*boost)
        ea=ch+boost
        refsig=2.d0*ea*ea*qlm_dh_sigma2(i,j,hn)
        den=qlm_dh_ak_sigma_tensor2(i,j,hn)-refsig
        sum_sp2=sum_sp2+(den/max(abs(refsig),1.d-30))**2
        asum_sp2=asum_sp2+qlm_dh_measure(i,j,hn)*(den/max(abs(refsig),1.d-30))**2
        zeta_ref=qlm_nptau(i,j,hn)-ea*ea*qlm_npkappa(i,j,hn)
        refzet=2.d0*real(zeta_ref*conjg(zeta_ref))
        den=qlm_dh_ak_zeta_direct2(i,j,hn)-refzet
        sum_zp2=sum_zp2+(den/max(abs(refzet),1.d-30))**2
        asum_zp2=asum_zp2+qlm_dh_measure(i,j,hn)*(den/max(abs(refzet),1.d-30))**2
        nvalid=nvalid+1
     end do
  end do
  if (nvalid > 0) then
     qlm_dh_audit_det3_min(hn)=detmin
     qlm_dh_audit_theta_native_rms(hn)=sqrt(sum_tn2/nvalid)
     qlm_dh_audit_theta_recon_rms(hn)=sqrt(sum_tr2/nvalid)
     qlm_dh_audit_theta_diff_rms(hn)=sqrt(sum_td2/nvalid)
     qlm_dh_audit_theta_diff_max(hn)=max_td
     qlm_dh_audit_sigma_parity_rel_rms(hn)=sqrt(sum_sp2/nvalid)
     qlm_dh_audit_zeta_parity_rel_rms(hn)=sqrt(sum_zp2/nvalid)
     qlm_dh_audit_valid_surface_fraction(hn)=1.d0
     if (asum > 0.d0) then
        qlm_dh_audit_theta_native_area_rms(hn)=sqrt(asum_tn2/asum)
        qlm_dh_audit_theta_recon_area_rms(hn)=sqrt(asum_tr2/asum)
        qlm_dh_audit_theta_diff_area_rms(hn)=sqrt(asum_td2/asum)
        qlm_dh_audit_sigma_parity_rel_area_rms(hn)=sqrt(asum_sp2/asum)
        qlm_dh_audit_zeta_parity_rel_area_rms(hn)=sqrt(asum_zp2/asum)
     end if
  end if
  dt = qlm_time(hn) - qlm_time_p(hn)

  ! Under the documented QLM world-tube change of variables,
  ! N_R*d sigma/dt = dR/dt.  Emit the N_R-weighted rate explicitly.
  if (dt > 0.d0) then
     drdt = (qlm_radius(hn) - qlm_radius_p(hn)) / dt
     qlm_dh_dR_dt(hn) = drdt
      qlm_dh_nr_full_flux_rate(hn) = drdt * qlm_dh_full_flux_surface_integral(hn)
     ak_integral = 0.d0
     do j=1+qlm_nghostsphi(hn),qlm_nphi(hn)-qlm_nghostsphi(hn)
        do i=1+qlm_nghoststheta(hn),qlm_ntheta(hn)-qlm_nghoststheta(hn)
           boost=qlm_dh_sinh_alpha(i,j,hn)
           if (boost > 0.d0) then
              qlm_dh_N_R(i,j,hn)=abs(drdt)/boost
               qlm_dh_ak_flux_density(i,j,hn)=qlm_dh_ak_full_flux_density(i,j,hn)*qlm_dh_N_R(i,j,hn)
              ak_integral=ak_integral+qlm_dh_ak_flux_density(i,j,hn)
           end if
        end do
     end do
     qlm_dh_ak_flux_surface_integral(hn)=ak_integral
     qlm_dh_evolution_status(hn) = 2.d0
  end if
end subroutine qlm_dh_finalize
